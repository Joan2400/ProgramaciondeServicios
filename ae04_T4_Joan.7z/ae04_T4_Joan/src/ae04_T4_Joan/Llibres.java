package ae04_T4_Joan;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

public class Llibres {

	//main
	//Parametro de entrada: String[] args
	//Parametro de salida: void
	//Este metodo inicializa todo el programa
	public static void main(String[] args) throws IOException {

		Scanner sc = new Scanner(System.in);
		
		int opcion = 0;
		
		do {
			System.out.println("Bienvenido al menu");
			System.out.println("Pulse 1 para subir los libros a la base de datos");
			System.out.println("Pulse 2 para sacar los libros que salieron antes del 1950");
			System.out.println("Pulse 3 para sacar las editoriales que han publicado almenos un libro en el siglo 21");
			System.out.println("Pulse 4 para salir");
			opcion = sc.nextInt();
			
			switch(opcion) {
			
			case 1:
				subirLibros();
				break;
			case 2:
				sacarAutores();
				break;
			case 3:
				sacarEditoriales();
				break;
			case 4:
				System.out.println("Gracias por utilizar nuestro programa");
				break;
			default:
				System.out.println("Error. Ponga el numero del 1 al 4");
				break;
			}
			
		}
		while(opcion != 4);



	}

	//leerArchivo()
	//Parametro de entrada: ninguno
	//Parametro de salida: ArrayList<String[]>
	//Lee el archivo para almacenarlo en un ArrayList para poder subirlo a la base de datos
	public static ArrayList<String[]> leerArchivo() throws IOException {
		String fichero = ".\\src\\ae04_T4_Joan\\AE04_T1_4_JDBC_Dades.csv";

		BufferedReader br = new BufferedReader(new FileReader(fichero));

		String linea = "";
		ArrayList<String[]> libro = new ArrayList<>();

		while((linea = br.readLine()) != null) {
			String[] datos = linea.split(";");
			libro.add(datos);
		}

		return libro;

	}

	//subirLibros()
	//Parametro de entrada: ninguno
	//Parametro de salida: void
	//Sube los libros guardados anteriormente a la base de datos
	public static void subirLibros() throws IOException {
		ArrayList<String[]> datos = leerArchivo();


		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con =
					DriverManager.getConnection("jdbc:mysql://localhost:3306/libreria","root","");
			Statement stmt = con.createStatement();
			for (int i = 1; i < datos.size(); i++) {

				String[] datos2 = datos.get(i) ;
				PreparedStatement psInsertar = con.prepareStatement("INSERT INTO llibres (Titol, Autor, AnyNaixement, AnyPublicacio, Editorial, NumPagines) VALUES (?,?,?,?,?,?)");
				psInsertar.setString(1,datos2[0]);
				psInsertar.setString(2,datos2[1]);
				psInsertar.setString(3,datos2[2]);
				psInsertar.setString(4, datos2[3]);
				psInsertar.setString(5, datos2[4]);
				psInsertar.setString(6, datos2[5]);
				int resultadoInsertar = psInsertar.executeUpdate();

				System.out.println("Libro a�adido correctamente");

			}

			stmt.close();
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	//sacarAutores()
	//Parametro de entrada: ninguno
	//Parametro de salida: void
	//Saca los autores de una fecha exacta de la base de datos
	public static void sacarAutores() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con =
					DriverManager.getConnection("jdbc:mysql://localhost:3306/libreria","root","");
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT Titol, Autor, AnyPublicacio FROM llibres WHERE AnyNaixement < 1950 ");
			while(rs.next()) {
				System.out.println("Titulo: " + rs.getString(1));
				System.out.println("Autor: " + rs.getString(2));
				System.out.println("Fecha Publicacion: " + rs.getInt(3));
			}
			rs.close();
			stmt.close();
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	//sacarEditoriales()
	//Parametro de entrada: ninguno
	//Parametro de salida: void
	//Saca las editoriales de un especifico a�o de la base de datos
	public static void sacarEditoriales() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con =
					DriverManager.getConnection("jdbc:mysql://localhost:3306/libreria","root","");
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT Editorial FROM llibres WHERE AnyPublicacio >=  2000");
			while(rs.next()) {
				System.out.println("Editorial: " + rs.getString(1));
			}
			rs.close();
			stmt.close();
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
